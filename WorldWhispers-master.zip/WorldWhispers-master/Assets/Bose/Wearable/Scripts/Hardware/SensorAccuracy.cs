﻿namespace Bose.Wearable
{
	public enum SensorAccuracy
	{
		Unreliable,
		Low,
		Medium,
		High
	}
}
