namespace Bose.Wearable
{
	public enum ProviderId
	{
		DebugProvider,
		WearableDevice,
		MobileProvider,
		WearableProxy
	}
}
