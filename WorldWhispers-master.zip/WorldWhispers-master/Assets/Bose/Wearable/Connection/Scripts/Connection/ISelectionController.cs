﻿namespace Bose.Wearable
{
	public interface ISelectionController<T>
	{
		void OnSelect(T value);
	}
}
